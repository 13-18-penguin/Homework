const modal = document.getElementById('modal');
const modalImg = document.getElementById('modal-img');
const modalTitle = document.getElementById('modal-title');
const modalRecipe = document.getElementById('modal-recipe');

document.querySelectorAll('.recipe').forEach(r => {
  r.onclick = () => {
    modalImg.src = r.querySelector('img').src;
    modalTitle.textContent = r.dataset.title;
    modalRecipe.textContent = r.dataset.recipe;
    modal.style.display = 'flex';
  }
});

document.getElementById('close').onclick = () => modal.style.display = 'none';

window.onclick = e => {
  if (e.target === modal) modal.style.display = 'none';
}
